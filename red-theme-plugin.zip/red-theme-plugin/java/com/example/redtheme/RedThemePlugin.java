package com.example.redtheme;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import cat.narezany.margyt.plugin.MargyPlugin;

public final class RedThemePlugin extends MargyPlugin {
    
    private static final int DARK_BLACK = Color.parseColor("#000000");
    private static final int DARK_GRAY = Color.parseColor("#0F0F0F");
    private static final int DARK_GRAY2 = Color.parseColor("#1A1A1A");
    private static final int DARK_GRAY3 = Color.parseColor("#181818");
    
    private static final int RED_DARK = Color.parseColor("#8B0000");
    private static final int RED_MEDIUM = Color.parseColor("#DC143C");
    private static final int RED_LIGHT = Color.parseColor("#FF1744");
    
    @Override
    public void onStart(Context context) {
        margyt().log("Red Theme Plugin started!");
    }
    
    @Override
    public void onActivityResumed(Activity activity) {
        try {
            View rootView = activity.getWindow().getDecorView();
            applyRedTheme(rootView);
            margyt().log("Red theme applied on: " + activity.getClass().getSimpleName());
        } catch (Exception e) {
            margyt().log("Error: " + e.getMessage());
        }
    }
    
    /**
     * Рекурсивно применяет красную тему ко всем View
     */
    private void applyRedTheme(View view) {
        int bgColor = view.getBackgroundColor();
        int textColor = 0;
        
        // Меняем фон чёрного на красный
        if (bgColor == DARK_BLACK || bgColor == DARK_GRAY || 
            bgColor == DARK_GRAY2 || bgColor == DARK_GRAY3 || bgColor == Color.BLACK) {
            view.setBackgroundColor(RED_DARK);
            margyt().log("Changed background to red");
        }
        
        // Если это TextView или имеет текст
        try {
            if (view instanceof android.widget.TextView) {
                android.widget.TextView textView = (android.widget.TextView) view;
                int currentTextColor = textView.getCurrentTextColor();
                
                // Если текст белый или светлый — оставляем белым
                if (currentTextColor == Color.WHITE || currentTextColor == -1) {
                    textView.setTextColor(Color.WHITE);
                }
            }
        } catch (Exception e) {
            // Игнорируем ошибки
        }
        
        // Рекурсивно обрабатываем дочерние View
        if (view instanceof ViewGroup && !(view instanceof android.widget.ProgressBar)) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                applyRedTheme(viewGroup.getChildAt(i));
            }
        }
    }
    
    @Override
    public void onStop() {
        margyt().log("Red Theme Plugin stopped!");
    }
}
